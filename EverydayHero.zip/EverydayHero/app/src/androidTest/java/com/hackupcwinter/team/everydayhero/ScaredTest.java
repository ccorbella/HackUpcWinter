package com.hackupcwinter.team.everydayhero;

import static org.junit.Assert.*;

/**
 * Created by gemma on 5/3/2017.
 */
public class ScaredTest {

}