package com.hackupcwinter.team.everydayhero;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.media.MediaPlayer;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    MediaPlayer mp;

    public void ClickDanger(View v) {
        //this.finish();
        startActivity(new Intent(MainActivity.this, Scared.class));
    }

    public void openChat(View v) {
        startActivity(new Intent(MainActivity.this, Chat.class));
    }

    private void dialContactPhone(final String phoneNumber) {
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }

    //public float getVolume() {
    //    float currVol = (float)sp.getInf("volume",10);
    //    float maxVol = 15.0f;
      //  float result = currVol/maxVol;
     //   return result;
    //}


    public void ClickSOS(View v) {
        //player.setVolume(getVolume(), getVolume());
        mp = MediaPlayer.create(MainActivity.this, R.raw.alarma);
        mp.start();
        dialContactPhone("112");
    }

    private void openWeb(final String uurl) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uurl)));
    }

    public void ClickHero(View V) {
        openWeb("http://www.maps.google.com");
    }






}





