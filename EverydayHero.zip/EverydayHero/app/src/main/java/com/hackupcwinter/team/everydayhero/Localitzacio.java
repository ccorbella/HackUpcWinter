package com.hackupcwinter.team.everydayhero;

import android.location.Location;

import android.telephony.TelephonyManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.widget.TextView;
import android.provider.Settings.Secure;

import android.telephony.TelephonyManager;
import android.content.Context;

import static java.security.AccessController.getContext;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.app.Application;
import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;


/**
 * Created by gemma on 4/3/2017.
 */

public class Localitzacio{
    //private String id;
    private String type;
    public TextView Latitude;
    public TextView Longitude;
    private Float value;
    private String timeString;
    private Date time;

    //private String android_id = Secure.getString(getContext(), getContentResolver(), Secure.ANDROID_ID);
    //final String deviceId = ((TelephonyManager) Context .getSystemService(Context.TELEPHONY_SERVICE)) .getDeviceID();
    //String id = Secure.getString( Secure.ANDROID_ID);
    //TelephonyManager telephonyManager;

    //telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
    //String id = telephonyManager.getDeviceId();
    String id = String.valueOf(1);

    //public String this.id;

    public Localitzacio(TextView newLatitude, TextView newLongitude){
        Latitude = newLatitude;
        Longitude = newLongitude;
    }
    public String getId() {
        return id;
    }
    //public void setId(String id) {
      //  this.id = id;
    //}
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Float getValue() {
        return value;
    }
    public void setValue(Float value) {
        this.value = value;
    }
    public String getTimeString() {
        return timeString;
    }
    public void setTimeString(String timeString) {
        this.timeString = timeString;
    }
    public Date getTime() {
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss");
        try {
            Date date = format.parse(timeString);
            setTime(date);
        } catch (ParseException e) {
            Log.e("Error", "No ha interpretat la data");
            e.printStackTrace();
        }
        return time;
    }
    public void setTime(Date time) {
        this.time = time;
    }
    public TextView getLatitude() {
        return Latitude;
    }
    public TextView getLongitude() {
        return Longitude;
    }
    public void actualize(){
        String s = "";
        try{
            s = updateInfo();
        }
        catch(Exception e){}


        //Log.e("Lectura del server", s);
        try {
            fillData(s);
        }
        catch (Exception e){
            e.printStackTrace();
            Log.e("LIADA", "Liada pardiiiiisimaaa");
        }
    }

    public String updateInfo() throws Exception {
        String url = "http://ec2-35-167-168-2.us-west-2.compute.amazonaws.com:5000/" + getId();
        //String key = "a0f562f2837bb36d9f9abfeb581ee1d69d068ffc4601bfa67049e6077575e505";

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        con.setRequestMethod("GET");
        //con.setRequestProperty("IDENTITY_KEY", key);

        //int responseCode = con.getResponseCode();

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }

        in.close();
        Log.e("LECTURA", "Liada pardiiiiisimaaa");
        return response.toString();
    }

    public void fillData(String sb) throws JSONException{
        JSONObject jObject = new JSONObject(sb);
        JSONArray jArray = jObject.getJSONArray("observations");
        for (int i=0; i < jArray.length(); i++) {
            try {
                JSONObject oneObject = jArray.getJSONObject(i);
                setValue(Float.parseFloat(oneObject.getString("value")));
                setTimeString(oneObject.getString("timestamp"));
            } catch (JSONException e) { }
        }
    }


}
